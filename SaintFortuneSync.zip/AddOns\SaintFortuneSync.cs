#region Using declarations
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public class SaintFortuneSync : AddOnBase
    {
        private const string SB_URL = "https://qkuimdilzxhhxpnvlnjb.supabase.co";
        private const string SB_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFrdWltZGlsenhoaHhwbnZsbmpiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE5NTQzNjQsImV4cCI6MjA5NzUzMDM2NH0.9kkAuNYuuU6G5EIgXk3ZO7nKxs6IVwjlzAAGggcn0Dk";

        private static readonly HttpClient _http = new HttpClient();
        private int _syncedCount = 0;
        private readonly HashSet<string> _sentIds = new HashSet<string>();
        private readonly Dictionary<string, TradeEntry> _openTrades = new Dictionary<string, TradeEntry>();

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
                Name = "SaintFortune Sync";
        }

        protected override void OnWindowCreated(Window window)
        {
            SubscribeToAccounts();
        }

        private void SubscribeToAccounts()
        {
            foreach (var acc in Account.All)
                acc.ExecutionUpdate += OnExecutionUpdate;
        }

        private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            if (e.Execution == null) return;
            TrackExecution(e.Execution);
        }

        private void TrackExecution(Execution exec)
        {
            var orderId = exec.Order != null ? exec.Order.Id.ToString() : Guid.NewGuid().ToString();

            if (exec.Order != null && (exec.Order.OrderAction == OrderAction.Buy || exec.Order.OrderAction == OrderAction.SellShort))
            {
                if (!_openTrades.ContainsKey(orderId))
                {
                    _openTrades[orderId] = new TradeEntry
                    {
                        Instrument = exec.Instrument != null ? exec.Instrument.FullName : "?",
                        Direction  = exec.Order.OrderAction == OrderAction.Buy ? "Long" : "Short",
                        Contracts  = exec.Quantity,
                        EntryPrice = exec.Price,
                        EntryTime  = exec.Time,
                        Account    = exec.Account != null ? exec.Account.Name : ""
                    };
                }
                return;
            }

            TradeEntry entry = null;
            string matchKey = null;
            string instrName = exec.Instrument != null ? exec.Instrument.FullName : "";
            string accName   = exec.Account != null ? exec.Account.Name : "";

            // Antes: emparejaba el cierre con la primera entrada abierta que
            // coincidiera en INSTRUMENTO, sin mirar la cuenta. Con dos o más
            // cuentas conectadas a la vez (ej. LUCID 50K + SimAccount1), si
            // ambas tenían el mismo instrumento abierto, un cierre podía
            // emparejarse con la entrada de la cuenta equivocada. Ahora exige
            // que coincidan instrumento Y cuenta.
            foreach (var kv in _openTrades)
            {
                if (kv.Value.Instrument == instrName && kv.Value.Account == accName && entry == null)
                {
                    entry    = kv.Value;
                    matchKey = kv.Key;
                }
            }

            if (entry == null) return;
            if (matchKey != null) _openTrades.Remove(matchKey);

            string tradeId = "NT-" + exec.ExecutionId;
            if (_sentIds.Contains(tradeId)) return;
            _sentIds.Add(tradeId);

            double pointValue = GetPointValue(entry.Instrument);
            double priceDiff  = entry.Direction == "Long" ? exec.Price - entry.EntryPrice : entry.EntryPrice - exec.Price;
            double grossPnl   = priceDiff * pointValue * entry.Contracts;
            double commission  = exec.Commission + (entry.Commission.HasValue ? entry.Commission.Value : 0);
            double netPnl      = grossPnl - commission;
            int durationSecs   = (int)(exec.Time - entry.EntryTime).TotalSeconds;

            string json = "{" +
                "\"id\":\"" + tradeId + "\"," +
                "\"account\":\"" + entry.Account + "\"," +
                "\"instrument\":\"" + entry.Instrument + "\"," +
                "\"direction\":\"" + entry.Direction + "\"," +
                "\"contracts\":" + entry.Contracts + "," +
                "\"entry_price\":" + entry.EntryPrice.ToString(System.Globalization.CultureInfo.InvariantCulture) + "," +
                "\"exit_price\":" + exec.Price.ToString(System.Globalization.CultureInfo.InvariantCulture) + "," +
                "\"entry_time\":\"" + entry.EntryTime.ToString("o") + "\"," +
                "\"exit_time\":\"" + exec.Time.ToString("o") + "\"," +
                "\"duration_secs\":" + durationSecs + "," +
                "\"pnl\":" + Math.Round(grossPnl, 2).ToString(System.Globalization.CultureInfo.InvariantCulture) + "," +
                "\"commission\":" + Math.Round(commission, 2).ToString(System.Globalization.CultureInfo.InvariantCulture) + "," +
                "\"net_pnl\":" + Math.Round(netPnl, 2).ToString(System.Globalization.CultureInfo.InvariantCulture) + "," +
                "\"notes\":\"\"" +
                "}";

            Task.Run(() => PushToSupabase(json));
        }

        private async Task PushToSupabase(string json)
        {
            try
            {
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                _http.DefaultRequestHeaders.Clear();
                _http.DefaultRequestHeaders.Add("apikey", SB_KEY);
                _http.DefaultRequestHeaders.Add("Authorization", "Bearer " + SB_KEY);
                _http.DefaultRequestHeaders.Add("Prefer", "resolution=merge-duplicates");

                var res = await _http.PostAsync(SB_URL + "/rest/v1/nt8_trades", content);

                if (res.IsSuccessStatusCode)
                {
                    _syncedCount++;
                    NinjaTrader.Code.Output.Process("SF Sync OK: " + _syncedCount + " trades enviados", PrintTo.OutputTab1);
                }
                else
                {
                    var err = await res.Content.ReadAsStringAsync();
                    NinjaTrader.Code.Output.Process("SF Sync error: " + res.StatusCode + " - " + err, PrintTo.OutputTab1);
                }
            }
            catch (Exception ex)
            {
                NinjaTrader.Code.Output.Process("SF Sync exception: " + ex.Message, PrintTo.OutputTab1);
            }
        }

        private double GetPointValue(string instrument)
        {
            if (instrument.Contains("MES")) return 5;
            if (instrument.Contains("ES"))  return 50;
            if (instrument.Contains("MNQ")) return 2;
            if (instrument.Contains("NQ"))  return 20;
            if (instrument.Contains("CL"))  return 100;
            if (instrument.Contains("GC"))  return 10;
            if (instrument.Contains("RTY")) return 10;
            return 1;
        }

        protected override void OnWindowDestroyed(Window window)
        {
            foreach (var acc in Account.All)
                acc.ExecutionUpdate -= OnExecutionUpdate;
        }
    }

    internal class TradeEntry
    {
        public string   Instrument  { get; set; }
        public string   Direction   { get; set; }
        public int      Contracts   { get; set; }
        public double   EntryPrice  { get; set; }
        public DateTime EntryTime   { get; set; }
        public string   Account     { get; set; }
        public double?  Commission  { get; set; }
    }
}